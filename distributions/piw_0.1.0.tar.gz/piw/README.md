# PIW

PI-weight R implement 

# How to install 

devtools::install_git("http://168.131.81.91:9999/sygstat/piw")

